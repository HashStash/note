//#"""
//#Created By GodStashX|HashStashX On Group CPVP(https://repl.it/cpvp) You Can View The Site: https://note.cpvp.repl.co
//# """

function deleteNote(noteId) {
  fetch("/delete-note", {
    method: "POST",
    body: JSON.stringify({ noteId: noteId }),
  }).then((_res) => {
    window.location.href = "/";
  });
}
