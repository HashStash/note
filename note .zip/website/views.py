#"""
#Created By GodStashX|HashStashX On Group CPVP(https://repl.it/cpvp) You Can View The Site: https://note.cpvp.repl.co
# """
from flask import Blueprint, render_template, request, flash, jsonify
from flask_login import login_required, current_user
from .models import Note
import random
from . import db
import json
import time
import colorama
from colorama import *

f = open("Notes.txt", 'a')
red = Fore.RED
blue = Fore.BLUE
green = Fore.GREEN
reset = Fore.RESET

localtime = time.localtime()
timeee = time.strftime('\n  [%H:%M %S]  %d/%m/%Y |  ')

views = Blueprint('views', __name__)
route = views.route
  
@route('/bot')
def bot():
  return "Bot?"
@route('/checkmate')
def checkmate():
    return render_template("checkmate.html")
@route('/links')
def links():
    return render_template('links.html')
@route('/', methods=['GET', 'POST'])
@login_required
def home():
    if request.method == 'POST':
        note = request.form.get('note')

        if len(note) > 200:
            rand = random.randint(1,5)
            if rand == 3:
                flash('Note Is Too LongDumbass')
            else:
                flash('Note is too Long!', category='error')
        
          
        else:
            new_note = Note(data=note, user_id=current_user.id)
            db.session.add(new_note)
            db.session.commit()
            flash('Note added!', category='success')
            print('{}A New Note Has Been Added: {}{}'.format(blue, note, reset))
            f.writelines("\n{}\n".format(note))

    return render_template("home.html", user=current_user)


@route('/delete-note', methods=['POST'])
def delete_note():
    note = json.loads(request.data)
    noteId = note['noteId']
    note = Note.query.get(noteId)
    if note:
        if note.user_id == current_user.id:
            db.session.delete(note)
            print(' {}  A USER DELETED {}{} '.format(red, note,reset))
            db.session.commit()

    return jsonify({})
