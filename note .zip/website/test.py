#"""
#Created By GodStashX|HashStashX On Group CPVP(https://repl.it/cpvp) You Can View The Site: https://note.cpvp.repl.co
# """
f = open('log.txt', 'a')
f.write('test')
while 1:
  return timeee
route = auth.route